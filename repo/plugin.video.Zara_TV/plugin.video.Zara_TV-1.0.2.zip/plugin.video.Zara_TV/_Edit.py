import xbmcaddon

MainBase = 'http://pastebin.com/raw/e09mjJYE'
addon = xbmcaddon.Addon('plugin.video.Zara_TV')