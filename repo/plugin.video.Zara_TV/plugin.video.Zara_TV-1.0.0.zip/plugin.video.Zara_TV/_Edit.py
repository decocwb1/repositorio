import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/ZaraSeries/lista/master/ZaraTV.m3u'
addon = xbmcaddon.Addon('plugin.video.Zara_TV')