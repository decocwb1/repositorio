import xbmcaddon

MainBase = 'http://pastebin.com/raw/xmnn7ySW'
addon = xbmcaddon.Addon('plugin.video.Zara_TV')