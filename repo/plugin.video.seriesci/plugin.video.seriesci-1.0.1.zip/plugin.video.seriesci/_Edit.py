import xbmcaddon

MainBase = 'http://pastebin.com/raw/e48tPCBf'
addon = xbmcaddon.Addon('plugin.video.seriesci')